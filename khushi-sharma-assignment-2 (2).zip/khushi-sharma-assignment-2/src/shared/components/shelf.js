import Book from "./book";

function Shelf(props) {
    return (
        <div className="bookshelf">
            <h2 className="bookshelf-title">{props.title}</h2>
            <div className="bookshelf-books">
                {props.books.length > 0 && <>
                    <ol className="books-grid">
                        {props.books.map((book, i) => <li key={`shelf-${i}`}><Book {...book} handleShelf={props.handleShelf} /></li>)}
                    </ol>
                </>}
            </div>
        </div>
    );
}

export default Shelf;