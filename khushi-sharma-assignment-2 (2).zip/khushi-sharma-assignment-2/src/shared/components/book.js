import { httpPatch } from "../services/http";

function Book(props) {
    const shelfChange = (e) => {
        httpPatch(`books/${props.id}`, { shelf: e.target.value }).then(res => {
            if (props.handleShelf) {
                props.handleShelf(props, res);
            }
        });
    }
    return (
        <div className="book">
            <div className="book-top">
                <div className="book-cover">
                    <img src={props?.imageLinks?.smallThumbnail} alt={props.title} />
                </div>
                <div className="book-shelf-changer">
                    <select onChange={shelfChange} value={props?.shelf || ''}>
                        <optgroup label="Move to...">
                            <option value="currentlyReading">Currently Reading</option>
                            <option value="wantToRead">Want to Read</option>
                            <option value="read">Read</option>
                            <option value="">None</option>
                        </optgroup>
                    </select>
                </div>
            </div>
            <div className="book-title">{props.title}</div>
            <div className="book-title">{props.subtitle}</div>
            <div className="book-authors">{props.authors}</div>
        </div>
    );
}

export default Book;