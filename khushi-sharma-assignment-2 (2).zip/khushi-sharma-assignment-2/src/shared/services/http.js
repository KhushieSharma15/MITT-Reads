const REACT_APP_API_ENDPOINT = 'http://localhost:3000/';

const request = (method, route, params) => {
    let httpConfig = {
        method: method,
        crossDomain: true,
        xhrFields: {
            withCredentials: true
        },
        headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
        },
        credentials: 'include'
    };
    if (method === 'POST' || method === 'PUT' || method === 'PATCH') {
        httpConfig = {
            ...httpConfig,
            body: JSON.stringify(params)
        };
    } else {
        route += '?' + (new URLSearchParams(params));
    }
    return new Promise((resolve) => {
        fetch(`${REACT_APP_API_ENDPOINT}${route}`, httpConfig)
            .then(res => res.json())
            .then(res => {
                return resolve(res);
            })
            .catch(err => console.error(err))
    })
}

export const httpPatch = (route, params) => request('PATCH', route, params);
export const httpGet = (route, params) => request('GET', route, params);
