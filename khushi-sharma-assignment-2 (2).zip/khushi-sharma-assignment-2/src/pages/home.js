import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import Shelf from "../shared/components/shelf";
import { httpGet } from "../shared/services/http";

function Home() {
    const [crBooks, setCrBooks] = useState([]);
    const [wrBooks, setWrBooks] = useState([]);
    const [rdBooks, setRdBooks] = useState([]);

    const handleShelf = (prevBook, curBook) => {
        if (prevBook.shelf === 'currentlyReading') {
            setCrBooks(crBooks.filter(book => book.id !== prevBook.id));
        } else if (prevBook.shelf === 'wantToRead') {
            setWrBooks(wrBooks.filter(book => book.id !== prevBook.id));
        } else if (prevBook.shelf === 'read') {
            setRdBooks(rdBooks.filter(book => book.id !== prevBook.id));
        }

        if (curBook.shelf === 'currentlyReading') {
            setCrBooks([...crBooks, curBook]);
        } else if (curBook.shelf === 'wantToRead') {
            setWrBooks([...wrBooks, curBook]);
        } else if (curBook.shelf === 'read') {
            setRdBooks([...rdBooks, curBook]);
        }
    };

    useEffect(() => {
        httpGet('books', { shelf: 'currentlyReading' }).then(res => {
            setCrBooks(res);
        });
        httpGet('books', { shelf: 'wantToRead' }).then(res => {
            setWrBooks(res);
        });
        httpGet('books', { shelf: 'read' }).then(res => {
            setRdBooks(res);
        });
    }, []);

    return (
        <div className="app">
            <div className="list-books">
                <div className="list-books-title">
                    <h1>MITTReads</h1>
                </div>
                <div className="list-books-content">
                    <div>
                        <Shelf title="Currently Reading" books={crBooks} handleShelf={handleShelf} />
                    </div>
                    <div>
                        <Shelf tag="wantToRead" title="Want To Read" books={wrBooks} handleShelf={handleShelf} />
                    </div>
                    <div>
                        <Shelf tag="read" title="Read" books={rdBooks} handleShelf={handleShelf} />
                    </div>
                </div>
                <div className="open-search">
                    <Link to="/search">Add a book</Link>
                </div>
            </div>
        </div>
    );
}

export default Home;
