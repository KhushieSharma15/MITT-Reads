import { Link } from "react-router-dom";
import Book from "../shared/components/book";
import { debounce } from 'throttle-debounce';
import { useState } from "react";
import { httpGet } from "../shared/services/http";

function Search() {

    const [searchBooks, setSearchBooks] = useState([]);

    const handleShelf = (prevBook, curBook) => {
        const sBooks = searchBooks.map((book) => {
            if (book.id === curBook.id) {
                book.shelf = curBook.shelf;
            }
            return book;
        });
        setSearchBooks(sBooks);
    };

    const throttleFunc = debounce(500, (keyword) => {
        if (keyword !== '') {
            httpGet('books', { 'q': keyword }).then(res => {
                setSearchBooks(res);
            });
        } else {
            setSearchBooks([]);
        }
    });

    return (
        <div className="app">
            <div className="search-books">
                <div className="search-books-bar">
                    <Link className="close-search" to="/">Close</Link>
                    <div className="search-books-input-wrapper">
                        <input type="text" placeholder="Search by title or author" onChange={(e) => throttleFunc(e.target.value)} />
                    </div>
                </div>
                <div className="search-books-results">
                    {searchBooks.length > 0 && <>
                        <div className="results-quantity">Your search returned {searchBooks.length} results.</div>
                        <ol className="books-grid">
                            {searchBooks.map((book, i) => <li key={`search-book-${i}`}><Book {...book} handleShelf={handleShelf} /></li>)}
                        </ol>
                    </>}
                </div>
            </div>
        </div>
    );
}

export default Search;
